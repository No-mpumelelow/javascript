
import './App.css'
import React from 'react'
//import UserProfile from './UserProfile'
import Picture from './Picture';

function App() {
  return(
    <div>
      <Picture/>

    </div>
  );
  
}

export default App
