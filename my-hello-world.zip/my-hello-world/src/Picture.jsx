import './Picture.css'
import mountain from'../public/mountain.jpg'
function Picture(){
    return(
        <div className='container'>
            <div className='image'>
                <img src={mountain} alt="" />

            </div>
            <div className='head'>
            <h1>4 days ago</h1>
            <h2>Post One</h2>

            </div>
           <div className='para'>
           <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. In doloremque rem nulla placeat ipsa alias
                 ad molestiae possimus eveniet necessitatibus,
                 aperiam enim voluptates veritatis officia repellendus labore hic vero exercitationem.</p>

           </div>
           <div className='input'>
                <div className='in' >read  </div>
                 <div className='in'>views</div>
                 <div className='in'>comments</div>

           </div>
            

                 
        </div>
    );
}
export default Picture;